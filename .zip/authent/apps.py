from django.apps import AppConfig


class AuthentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'authent'
